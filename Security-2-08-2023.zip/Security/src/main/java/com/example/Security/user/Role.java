package com.example.Security.user;

public enum Role {
    USER,
    ADMIN;
}
